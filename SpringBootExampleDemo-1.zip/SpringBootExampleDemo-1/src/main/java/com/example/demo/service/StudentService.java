package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Student;
import com.example.demo.repository.StudentRepository;

@Service
public class StudentService {

	@Autowired
	private StudentRepository repository;

	public List<Student> getList() {

		// List<Student> students = new ArrayList<>();
		return repository.findAll();
	}

	public void addStudent(Student student) {

		repository.save(student);
	}
	
	public List<Student> addStudents(List<Student> students){
		
		return repository.saveAll(students);
	}

	public Student getStudentByName(String name) {

		return repository.getStudentByName(name);
	}
	
	public Student getStudentByRollNo(int rollNo) {

		Student s =null;
		try {
		s=repository.findById(rollNo).get();
		return s;
		}
		catch(Exception e) {
		return s;
		}
	}

	public Student updateStudent(int rollNo, Student student) {

		return repository.save(student);
	}
	
	public void deleteStudent(int rollNo){
		repository.deleteById(rollNo);
		
		
	}
	
	

}
