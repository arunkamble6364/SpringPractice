package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception.StudentNotFoundException;
import com.example.demo.model.Student;
import com.example.demo.service.StudentService;

@RestController
public class StudentController {

	@Autowired
	private StudentService service;

	@GetMapping("/getList")
	public List<Student> getStudentsList() {

		return service.getList();
	}

	@GetMapping("/getStudent")
	public Student getStudent(@RequestParam String name) {

		return service.getStudentByName(name);
	}

	@GetMapping("/getStudent/{name}")
	public Student getStudentByName(@PathVariable String name) {

		return service.getStudentByName(name);
	}

	@GetMapping("/getStudentByRollNo/{rollNo}")
	public Student getStudentByRollNo(@PathVariable int rollNo) {
		
		Student student = service.getStudentByRollNo(rollNo);
		if (student == null) {
			// runtime exception
			throw new StudentNotFoundException("rollNo not exist");
			
		}
		return student;

		// return service.getStudentByRollNo(rollNo);
	}

	/*
	 * @PostMapping("/addStudent") public String addStudent(@RequestBody Student
	 * student) {
	 * 
	 * service.addStudent(student); return "student added"; }
	 */

	@PostMapping("/addStudent")
	public ResponseEntity<Student> addStudent(@RequestBody Student student) {

		service.addStudent(student);
		return ResponseEntity.created(null).build();
	}

	@PostMapping("/addStudents")
	public List<Student> addStudents(@RequestBody List<Student> students) {
		return service.addStudents(students);
	}

	@PutMapping("/updateStudent/{rollNo}")
	public Student updateStudent(@PathVariable int rollNo, @RequestBody Student student) {

		return service.updateStudent(rollNo, student);

	}

	@DeleteMapping("/deleteStudent/{rollNo}")
	public String deleteStudent(@PathVariable int rollNo) {
		service.deleteStudent(rollNo);

		return "student deleted";
	}

}
