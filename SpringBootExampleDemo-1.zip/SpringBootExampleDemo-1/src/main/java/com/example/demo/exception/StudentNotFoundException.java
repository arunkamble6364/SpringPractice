package com.example.demo.exception;

import org.springframework.web.bind.annotation.ResponseStatus;


public class StudentNotFoundException extends RuntimeException {

	public StudentNotFoundException(String message) {
		super(message);
	}
	
	
}
