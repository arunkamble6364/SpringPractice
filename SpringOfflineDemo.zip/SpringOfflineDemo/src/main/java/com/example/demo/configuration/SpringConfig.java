package com.example.demo.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.example.demo.model.Product;

@Configuration
@ComponentScan(basePackages = {"com.example.demo.model" ,"com.example.demo.repository"})
public class SpringConfig {

	
	/*
	 * @Bean //@Bean("p1") public Product getProduct() {
	 * 
	 * Product p1 = new Product(); p1.setId(1); p1.setName("lux"); p1.setPrice(20);
	 * p1.setBrand("soap"); return p1;
	 * 
	 * }
	 * 
	 * //@Bean("p2")
	 * 
	 * @Bean
	 * 
	 * @Primary public Product getProduct1() {
	 * 
	 * Product p1 = new Product(); p1.setId(2); p1.setName("dettol");
	 * p1.setPrice(40); p1.setBrand("soap"); return p1;
	 * 
	 * }
	 */
	
	
	

}
