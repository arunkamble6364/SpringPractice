package com.example.demo.repository;

import java.util.List;

import com.example.demo.model.Person;

public interface PersonDao {

	public List<Person> getAllPersons();

	public List<Person> getAllPersonsGreaterThanAge(int age);

	public int insertPerson(Person p);

	public Person getPersonById(int id);

	public int deleteById(int id);

	public int updatePerson(Person p, int id);
}
