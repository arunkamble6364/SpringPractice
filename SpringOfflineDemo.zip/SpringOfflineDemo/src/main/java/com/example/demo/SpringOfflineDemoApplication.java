package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.example.demo.configuration.SpringConfig;
import com.example.demo.model.Person;
import com.example.demo.model.Product;
import com.example.demo.repository.PersonDao;

@SpringBootApplication
public class SpringOfflineDemoApplication implements CommandLineRunner {
	
	@Autowired
	PersonDao personRepository;

	public static void main(String[] args) {
		SpringApplication.run(SpringOfflineDemoApplication.class, args);
	}
	
	

	public void run(String... args) throws Exception {

		/*
		 * Product p1 = new Product(1, "lux", 20, "soap");
		 * 
		 * System.out.println(p1);
		 */

		// ApplicationContext context = new
		// AnnotationConfigApplicationContext(Product.class);
		// Product p1 = context.getBean(Product.class);

		// ApplicationContext context = new
		// AnnotationConfigApplicationContext(Product.class);

		/*
		 * ApplicationContext context = new
		 * AnnotationConfigApplicationContext(SpringConfig.class); Person p1 =
		 * context.getBean(Person.class); p1.getDog().bark();
		 */

		//ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);

		//PersonDao p = (PersonDao) context.getBean(PersonDao.class);
		
		
			// repository inmplementation code
		
		//personRepository.getAllPersons().stream().forEach(System.out::print);
		//personRepository.getAllPersonsGreaterThanAge(35).stream().forEach(System.out::print);
		
		//personRepository.insertPerson(new Person(9, "Ravi", 34, "ravi456@gmail.com"));
		
		
		//System.out.print(personRepository.getPersonById(3));
		
		//personRepository.deleteById(9);
		
		personRepository.updatePerson((new Person(2,"arvind",34 ,"arvind@gmail.com")), 2);


	}

}
