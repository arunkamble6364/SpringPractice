package com.example.demo.model;

import org.springframework.stereotype.Component;

@Component("pummerian")
public class PummerianDog implements Dog{

	@Override
	public void bark() {
		System.out.println("whoof whoof");
		
	}

}
