package com.example.demo.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.example.demo.model.Person;

public class PersonMapper implements RowMapper<Person> {

	@Override
	public Person mapRow(ResultSet rs, int rowNum) throws SQLException {
		Person p1 = new Person();
		p1.setId(rs.getInt(1));
		p1.setName(rs.getString(2));
		p1.setAge(rs.getInt(3));
		p1.setEmail(rs.getString(4));
		return p1;
	}

}
