package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Manufacturer;
import com.example.demo.model.Person;
import com.example.demo.model.Product;
import com.example.demo.repository.PersonDao;

@RestController
@RequestMapping("/person")
public class ProductController {

	/*
	 * @RequestMapping(method =RequestMethod.GET, value = "/get") public Product
	 * getProduct() {
	 * 
	 * Product p1 = new Product(); p1.setId(1); p1.setName("lux"); p1.setPrice(20);
	 * p1.setBrand("soap");
	 * 
	 * p1.setManufacturer(new Manufacturer("HU", "Pune")); return p1; }
	 */
	
	@Autowired
	PersonDao p;
	
	@RequestMapping(method =RequestMethod.GET, value = "/get/{id}" )
	public Person getPerson(@PathVariable("id") int id) {
		return p.getPersonById(id);
	}
	

}
