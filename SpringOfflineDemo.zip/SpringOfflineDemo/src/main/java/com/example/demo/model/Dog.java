package com.example.demo.model;

public interface Dog {
	
	public void bark();

}
