package com.example.demo.model;

import org.springframework.stereotype.Component;

@Component("labrador")
public class LabradorDog  implements Dog{

	@Override
	public void bark() {
		System.out.println("bhow bhow");
		
	}

}
