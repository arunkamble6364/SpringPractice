package com.example.demo.repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.example.demo.mapper.PersonMapper;
import com.example.demo.model.Person;

@Component
public class PersonDaoImpl implements PersonDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public List<Person> getAllPersons() {

		String sql = "select id, name, age, email from person";

		return jdbcTemplate.query(sql, new PersonMapper());

	}

	@Override
	public List<Person> getAllPersonsGreaterThanAge(int age) {

		String sql = "select id, name, age, email from person where age>=?";

		return jdbcTemplate.query(sql, new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setInt(1, age);

			}

		}, new PersonMapper());

	}

	@Override
	public int insertPerson(Person p) {

		String sql = "insert into person(id,name,age,email) values(?,?,?,?)";
		return jdbcTemplate.update(sql, new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setInt(1, p.getId());
				ps.setString(2, p.getName());
				ps.setInt(3, p.getAge());
				ps.setString(4, p.getEmail());

			}

		});

	}

	@SuppressWarnings("deprecation")
	@Override
	public Person getPersonById(int id) {

		String sql = "select id, name, age, email from person where id=?";
		return jdbcTemplate.queryForObject(sql, new Object[] { id }, new PersonMapper());

	}

	@Override
	public int deleteById(int id) {
		String sql = "delete from person where id=?";
		return jdbcTemplate.update(sql, new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setInt(1, id);

			}

		});
	}

	public int updatePerson(Person p, int id) {
		// TODO Auto-generated method stub
		String sql = "update person set name=?,age=?,email=? where id=?";
		return jdbcTemplate.update(sql, new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {

				ps.setString(1, p.getName());
				ps.setInt(2, p.getAge());
				ps.setString(3, p.getEmail());
				ps.setInt(4, p.getId());

			}

		});
	}

}
