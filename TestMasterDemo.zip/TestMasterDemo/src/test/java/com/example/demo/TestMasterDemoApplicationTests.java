package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.repository.TodoRepository;
import com.example.demo.service.CalcService;
import com.example.demo.service.TodoService;

@SpringBootTest
class TestMasterDemoApplicationTests {

	@Autowired
	CalcService service;

	@InjectMocks
	TodoService todoService;

	@Mock
	TodoRepository repo;

	@Test
	void contextLoads() {
	}

	@Test
	void testCalcAddInt() {
		assertEquals(5, service.addInt(2, 3));

	}

	/*
	 * @Test void testTodoServiceAdminTodos() { //
	 * assertEquals(2,todoService.getAllAdminTodos().size()); NullPointerException
	 * exception = Assertions.assertThrows(NullPointerException.class, () ->
	 * todoService.getAllAdminTodos()); assertEquals("list of todos is null",
	 * exception.getMessage());
	 * 
	 * }
	 */

	/*
	 * @Test void testTodoServiceUserTodos() {
	 * assertEquals(1,todoService.getAllUserTodos().size()); }
	 */

	@Test
	void testTodoServiceAdminTodos() {

		List<String> arr = Arrays.asList("ARUN_ADMIN", "AMIT_USER", "RAVI_ADMIN", "NEHA_DEVELOPER");
		when(repo.getAllTodos()).thenReturn(arr);
		assertEquals(2, todoService.getAllAdminTodos().size());

	}

	@Test
	void testTodoServiceWhenTodosNull() {

		when(repo.getAllTodos()).thenReturn(null);
		NullPointerException exception = Assertions.assertThrows(NullPointerException.class,
				() -> todoService.getAllAdminTodos());

		assertEquals("list of todos is null", exception.getMessage());

	}

}
