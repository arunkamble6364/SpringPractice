package com.example.demo.stub;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.repository.TodoRepository;

@Repository
public class TodoRepositoryImpl implements TodoRepository{

	@Override
	public List<String> getAllTodos() {
		
		return Arrays.asList("ARUN_ADMIN","AMIT_USER","RAVI_ADMIN","NEHA_DEVELOPER"); 
		//return null;
	}
	

}
