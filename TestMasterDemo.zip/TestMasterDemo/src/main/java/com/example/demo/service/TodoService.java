package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.repository.TodoRepository;

@Service
public class TodoService {
	
	@Autowired
	TodoRepository repo;
	
	public  List<String> getAllAdminTodos() {
		
		 List<String> adminTodos=new ArrayList<String>();
	        List<String> todos=repo.getAllTodos();
	        
	        if(todos==null)
	        	throw new NullPointerException("list of todos is null");
	        adminTodos = todos.stream().filter(todo -> todo.contains("ADMIN")).collect(Collectors.toList());
	        return adminTodos;
		
	}
	
	public  List<String> getAllUserTodos() {
		
		 List<String> adminTodos=new ArrayList<String>();
	        List<String> todos=repo.getAllTodos();
	        
	        adminTodos = todos.stream().filter(todo -> todo.contains("USER")).collect(Collectors.toList());
	        return adminTodos;
		
	}
	

}
