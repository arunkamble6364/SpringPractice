package com.example.demo.repository;

import java.util.List;

public interface TodoRepository {
	
	List<String> getAllTodos();

}
