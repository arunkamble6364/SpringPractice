package com.example.demo.service;

import org.springframework.stereotype.Component;

@Component
public class CalcServiceImpl  implements CalcService{

	@Override
	public int addInt(int a, int b) {
		// TODO Auto-generated method stub
		return a+b;
	}

}
