package com.example.demo.service;

public interface CalcService {
	
	
	public int addInt(int a, int b);

}
