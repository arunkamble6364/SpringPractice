package com.ComparableDemo;

public class Employee implements Comparable<Employee> {

	private int empId;
	private String name;
	private int age;

	public Employee(int empId, String name, int age) {
		super();
		this.empId = empId;
		this.name = name;
		this.age = age;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", age=" + age + "]";
	}

	@Override
	public int compareTo(Employee o) {
		// TODO Auto-generated method stub
		
		// based on empId
		/*
		 * if(this.empId < o.empId) { return -1; } else if (this.empId > o.empId) {
		 * return 1; } else return 0;
		 */
		
		// based on age
		
		/*
		 * if(this.age < o.age) { return -1; } else if (this.age > o.age) { return 1; }
		 * else return 0;
		 */
		
		// based on name
		return this.name.compareTo(o.name);
	}

}
