package com.ComparableDemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Employee> employees = new ArrayList<>();
		
		Employee e1 = new Employee(13, "Sagar", 24);
		Employee e2 = new Employee(5, "Amar", 56);
		Employee e3 = new Employee(26, "Mukesh", 98);
		Employee e4 = new Employee(78, "Jatin", 35);
		
		employees.add(e1);
		employees.add(e2);
		employees.add(e3);
		employees.add(e4);
		
		System.out.println("Original List is :" +employees);
		
		System.out.println(" List afer sorting : ");
		
		Collections.sort(employees);
		System.out.println(employees);
		
		
		
	}

}
