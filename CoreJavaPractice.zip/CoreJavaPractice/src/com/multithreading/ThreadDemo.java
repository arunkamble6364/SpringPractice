package com.multithreading;

import java.util.Map;
import java.util.Map.Entry;

class Sample extends Thread{
	
	public void run() {
		System.out.println("thread starts working");
	}
}


public class ThreadDemo {

	public static void main(String[] args) {
		
		
		Sample s1 = new Sample();
		s1.run();
		
		//System.out.println("hello");
		

	}

}
