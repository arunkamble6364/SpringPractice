package com.multithreading;

class Try extends Thread {

	public void run() {
		System.out.println("thread is running");
	}

}

public class ThreadNaming {

	public static void main(String[] args) {

		Try t1 = new Try();
		Try t2 = new Try();
		System.out.println("Name of t1 is :" + t1.getName());
		System.out.println("Id of t1 is :" + t1.getId());
		System.out.println("Name of t2 :" + t2.getName());
		t1.start();
		t2.start();
		t1.setName("Sachin");
		System.out.println("After changing the name :" + t1.getName());

	}

}
