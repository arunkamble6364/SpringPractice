package com.multithreading;

class Second extends Thread {

	public Second(String name) {
		this.setName(name);
	}

	public void run() {

		for (int i = 0; i < 5; i++) {

			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				System.out.println(e);
			}
			System.out.println(this.getName() + " " + i);
		}

	}

}

public class JoinDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		Second t1 = new Second("T1");
		Second t2 = new Second("T2");
		Second t3 = new Second("T3");

		t1.start();
		t1.join();
		t2.start();
		t3.start();
		

	}

}
