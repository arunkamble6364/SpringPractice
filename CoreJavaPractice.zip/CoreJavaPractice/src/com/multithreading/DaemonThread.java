package com.multithreading;

class You extends Thread{
	
	public void run() {
		
		if(Thread.currentThread().isDaemon()) {
			System.out.println("It is daemon thread");
		}
		else {
			System.out.println("It is user thread");
		}
	}
	
}

public class DaemonThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		You t1 = new You();
		You t2 = new You();
		//You t3 = new You();
		
		t1.setDaemon(true);
		
		t1.start();
		t2.start();
		//t3.start();

	}

}
