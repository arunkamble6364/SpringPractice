package com.multithreading;

class Demo implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("thread is working");
	}
	
}

public class ThreadCreation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Demo d1 = new Demo();
		Thread t1 = new Thread(d1);
		t1.run();

	}

}
