package com.string;

 final class Play{
	
	final String panCardNo;

	public Play(String panCardNo) {
		super();
		this.panCardNo = panCardNo;
	}

	public String getPanCardNo() {
		return panCardNo;
	}
	
	
	
}

public class ImmutableClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Play play = new Play("GMRPK2349D");
		String s = play.getPanCardNo();
		System.out.println("PaNCardNo is : " + s);
		
		
	}

}
