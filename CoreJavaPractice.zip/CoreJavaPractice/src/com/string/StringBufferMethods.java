package com.string;

public class StringBufferMethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// append method
		StringBuffer sb = new StringBuffer("Amit ");
		sb.append("Patil");
		System.out.println(sb);

		// insert
		StringBuffer sb1 = new StringBuffer("Dayanand");
		sb1.insert(2, "Hii");
		System.out.println(sb1);

		// delete method : begin index & end index consider
		StringBuffer sb2 = new StringBuffer("Vikram");
		sb2.delete(1, 4);
		System.out.println(sb2);
		
		// replace method
		StringBuffer sb3= new StringBuffer("Hello");
		sb3.replace(1, 4, "Demo");
		System.out.println(sb3);
		
		// reverse method 
		StringBuffer sb4 = new StringBuffer("Welcome");
		sb4.reverse();
		System.out.println(sb4);
		
		// capacity method
		StringBuffer sb5 = new StringBuffer();
		System.out.println(sb5.capacity());
		
		sb5.append("How are you");
		System.out.println(sb5.capacity());
		
		sb5.append("welcome to java");
		System.out.println(sb5.capacity());
		
		
		
		
		
		
		

	}

}
