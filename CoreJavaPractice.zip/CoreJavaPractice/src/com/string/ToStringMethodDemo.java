package com.string;

class Lion {

	int rollNo;
	String name;
	String address;

	public Lion(int rollNo, String name, String address) {
		super();
		this.rollNo = rollNo;
		this.name = name;
		this.address = address;
	}

	@Override
	public String toString() {
		return "Lion [rollNo=" + rollNo + ", name=" + name + ", address=" + address + "]";
	}

}

public class ToStringMethodDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Lion l1 = new Lion(1, "Samit", "Pune");
		System.out.println(l1);

	}

}
