package com.string;

public class StringDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s= "Kolhapur";
		System.out.println(s.charAt(1));
		System.out.println(s.length());
		System.out.println(s.toUpperCase());
		System.out.println(s.toLowerCase());
		System.out.println(s.substring(1, 4));
		

		String s1 = "sachin";
		s1.concat("tendulkar");
		System.out.println(s1);
		
		String s2 = "Virat";
		String s3= "Virat";
		String s4 = new String("Virat");
		System.out.println(s2.equals(s3));
		System.out.println(s2.equals(s4));
		
		System.out.println(s2==s3);
		System.out.println(s2==s4);
		
		
		String s5 = "Suresh";
		String s6 = "Suresh";
		String s7 = "Yuvi";
		
		System.out.println(s5.compareTo(s6));
		System.out.println(s5.compareTo(s7));
		System.out.println(s7.compareTo(s5));
		
		
		
	}

}
