package com.string;

public class StringClassMethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// concat method
		String s1 = "Hello";
		String s2 = "Welcome";
		String s3 = "All of you";
		
		String s4 = s1.concat(" ").concat(s2).concat(" ").concat(s3);
		System.out.println(s4);
		
		
		String s5= "Virat" + " Kohli";
		System.out.println(s5);
		
		
		// split method 
		
		String s7 = "kolhapur,pune,mumbai,solapur";

		String[] cities = s7.split(",");
		
		for(String city : cities) {
			System.out.println(city);
			
		}
		
		// replace method
		
		String s8 = "Java is a language. Java is a platform";
		String s9 = s8.replace("Java", "Kava");
		System.out.println(s9);
		
		String s10 = "";
		System.out.println(s10.isEmpty());
		
	}

}
