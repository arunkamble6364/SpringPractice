package com.oops;

interface Printable{
	void print();
	void show();
	
	default void msg() {
		System.out.println("fabulous");
	}
	static int cube(int x) {
		return x*x*x;
	}
}

class Sample implements Printable{

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("welcome to java");
		
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("welcome to project");
	}
	
}

public class InterfaceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Sample sample = new Sample();
		sample.print();
		sample.show();
		sample.msg();
		System.out.println(Printable.cube(3));
	}

}
