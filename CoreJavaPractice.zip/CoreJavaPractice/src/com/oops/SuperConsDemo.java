package com.oops;

class E {
	int id;
	String name;

	public E(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

}

class F extends E {

	String address;

	public F(int id, String name, String address) {
		super(id, name);
		this.address = address;

	}
	
	public void display() {
		System.out.println(id + " " +name + " " +address );
	}

}

public class SuperConsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		F obj = new F(1, "Pranav", "Pune");
		obj.display();
		
		
	}

}
