package com.oops;

class Demo implements Cloneable{
	
	int rollNo= 1;
	String name="Abhijeet";
	
	public String getDetails() {
		return rollNo+ " " +name;
	}
	
	public Demo clone() throws CloneNotSupportedException{
		return(Demo)super.clone();
	}
}

public class ObjectCloneDemo {

	public static void main(String[] args) throws CloneNotSupportedException{
		// TODO Auto-generated method stub

		Demo d1 = new Demo();
		Demo d2 = (Demo)d1.clone();
		System.out.println(d1.getDetails());
		System.out.println(d2.getDetails());
		
		
	}

}
