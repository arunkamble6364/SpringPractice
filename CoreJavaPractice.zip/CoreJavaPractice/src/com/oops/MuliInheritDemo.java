package com.oops;

interface Third{
	
	void show();
}

interface Second{
	void show();
}

class Skit implements Third,Second{

	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println(" Sample mode");
	}
	
}

public class MuliInheritDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Skit skit = new Skit();
		skit.show();
		
	}

}
