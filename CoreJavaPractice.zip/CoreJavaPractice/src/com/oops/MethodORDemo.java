package com.oops;

class C{
	void display() {
		System.out.println("Hello all");
	}
}
class D extends C{
	void display() {
		System.out.println("welcome");
	}
}


public class MethodORDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		C obj = new D();
		obj.display();
		
	}

}
