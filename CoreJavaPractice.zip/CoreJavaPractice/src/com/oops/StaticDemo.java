package com.oops;

class Student {

	int rollNo;
	String name;
	static String college = "KIT";

	public Student(int rollNo, String name) {
		super();
		this.rollNo = rollNo;
		this.name = name;
	}

	public void display() {
		System.out.println(rollNo + " " + name + " " + college);
	}

	static void change() {
		college = "VIT";
	}

}

public class StaticDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Student.change();
		Student s1 = new Student(1, "Tushar");
		Student s2 = new Student(2, "Ayush");
		s1.display();
		s2.display();

	}

}
