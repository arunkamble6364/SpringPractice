package com.oops;

class Address {
	String streetName = "Tilak road";
	String city = "Pune";
	int pincode = 416011;

}

class Person {

	int id;
	String name;
	Address address;

	public void displayAddress() {
		address = new Address();

		System.out.println(address.streetName + " " + address.city + " " + address.pincode);
	}

}

public class AggregationDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Person p = new Person();
		p.displayAddress();

	}

}
