package com.oops;

abstract class Shape {

	abstract void draw();
	
	public Shape() {
	
		System.out.println("welcome ");
	}
	
	static int cube(int x) {
		return x*x*x ;
	}
	
	public void print() {
		System.out.println("non abstract method called");
	}

}

class Circle extends Shape {

	@Override
	void draw() {
		System.out.println("circle drawing");
	}

}

class Rectangle extends Shape {

	@Override
	void draw() {
		// TODO Auto-generated method stub
		System.out.println("rectangle drawing");
	}

}

public class AbstractClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Shape s = new Rectangle();
		s.draw();
		s.print();
		System.out.println(Shape.cube(3));
		
		
	}

}
