package com.oops;

class School {

	private int sid;
	private String name;
	private String address;

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}

public class EncapsulationDemo {

	public static void main(String[] args) {

		School school = new School();
		school.setSid(1);
		school.setName("KIT");
		school.setAddress("Kolhapur");

		System.out.println(school.getSid() + " " + school.getName() + " " + school.getAddress());

	}

}
