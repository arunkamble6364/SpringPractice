package com.oops;

public class WrapperClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// autoboxing - primitive into object
		
		int a = 20;
		Integer b= a;
		System.out.println(a+ " " + b);
		
		// unboxing - object into primitive
		
		Integer c = new Integer(12);
		int d=c;
		System.out.println(c + " " + d);
	}

}
