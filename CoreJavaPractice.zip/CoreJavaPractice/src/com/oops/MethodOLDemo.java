package com.oops;

class Adder {

	public int add(int a, int b) {
		return a + b;

	}

	public int add(int a, int b, int c) {
		return a + b + c;
	}

	public double add(double p, double q) {
		return p + q;
	}
}

public class MethodOLDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Adder a = new Adder();
		System.out.println(a.add(10, 14));
		System.out.println(a.add(12, 87, 23));
		System.out.println(a.add(18.3, 15.8));

	}

}
