package com.oops;

class First{
	
	final int a= 20;

	public First() {
		super();
		// TODO Auto-generated constructor stub
		
	}
	
	
}

public class FinalDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		First first = new First();
		System.out.println(first.a );
		
	}

}
