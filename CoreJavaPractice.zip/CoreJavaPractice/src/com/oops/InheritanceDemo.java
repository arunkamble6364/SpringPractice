package com.oops;

class Animal {

	void eat() {
		System.out.println("eating grass");
	}
}

class Dog extends Animal {

	void bark() {
		System.out.println("eating bread");
	}
}
class Cat extends Animal{
	void meow() {
		System.out.println("cat sounds");
	}
}

public class InheritanceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * Dog dog = new Dog(); dog.bark(); dog.eat();
		 */
		
		Cat c= new Cat();
		c.meow();
		c.eat();
		
	}

}
