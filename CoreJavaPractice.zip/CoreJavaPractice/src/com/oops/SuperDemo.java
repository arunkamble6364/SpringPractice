package com.oops;

class M{
	String color= "white";
}

class N extends M{
	
	String color= "Black";
	
	void printColor() {
		System.out.println(color);
		System.out.println(super.color);
	}
}


public class SuperDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		N obj = new N();
		obj.printColor();
		
	}

}
