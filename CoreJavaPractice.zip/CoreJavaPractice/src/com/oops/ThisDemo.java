package com.oops;

class A{
	
	void m() {
		System.out.println("Hello");
	}
	void n() {
		System.out.println("welcome");
		this.m();
	}
}

public class ThisDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		A a = new A();
		a.n();
	}

}
