package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCDemo {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub

		Connection connection = null;

		try {

			Class.forName("com.mysql.jdbc.Driver");

			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/springcore","root","Arun6364@");
			
			Statement statement = connection.createStatement();

			String sql = "insert into empdemo values(1,'Kishor',24876,'Pune','HR')";
			
			statement.execute(sql);
			
			/*
			 * String sql = "insert into empdemo values(?,?,?,?,?)";
			 * 
			 * PreparedStatement preparedStatement = connection.prepareStatement(sql);
			 * 
			 * preparedStatement.execute();
			 */

		} catch (Exception e) {
			System.out.println(e);
		}

		finally {
			/*
			 * 
			 * try { connection.close(); } catch (SQLException e) { e.printStackTrace(); }
			 * 
			 * 
			 */
			connection.close();
		}

	}

}
