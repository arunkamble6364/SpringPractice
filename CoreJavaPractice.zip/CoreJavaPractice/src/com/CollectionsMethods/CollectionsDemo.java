package com.CollectionsMethods;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CollectionsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> list = new ArrayList<>();
		list.add(11);
		list.add(887);
		list.add(45);
		list.add(789);
		list.add(90);

		// max method
		System.out.println("Max number in list: " + Collections.max(list));

		// min method
		System.out.println("Min number in list: " + Collections.min(list));

		// sort method
		Collections.sort(list);
		System.out.println("Sorted list is :" + list);

		// swap method
		Collections.swap(list, 1, 3);
		System.out.println("swapped list is :" + list);

		// reverse method
		Collections.reverse(list);
		System.out.println("reversed list is :" + list);

		List<String> list2 = new ArrayList<>();
		list2.add("Arvind");
		list2.add("Mahesh");
		list2.add("Lalu");
		list2.add("Tushar");
		list2.add("Arvind");

		// replace all
		Collections.replaceAll(list2, "Arvind", "Rahul");
		System.out.println("replaced list is:" + list2);

		// reverse method
		Collections.reverse(list2);
		System.out.println("Reversed list is :" + list2);
		
		// fill method
		/*
		 * Collections.fill(list2, "Hardik"); System.out.println(list2);
		 */
		
		// frequency method
		System.out.println("frequency of Rahul is : "+Collections.frequency(list2, "Rahul"));
		
		

	}

}
