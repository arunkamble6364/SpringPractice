package com.collectionFramework;

import java.util.ArrayDeque;
import java.util.Deque;

public class ArrayDequeueDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Deque<String> deque = new ArrayDeque<>();
		deque.add("Omkar");
		deque.add("Sagar");
		deque.add("Ravi");

		System.out.println(deque);

	}

}
