package com.collectionFramework;

import java.util.Stack;

public class StackDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// It implements Lifo data structure
		
		Stack<String> stack = new Stack<>();
		stack.push("Atul");
		stack.push("Suraj");
		stack.push("Vaibhav");
		stack.push("Yash");
		
		stack.pop();
		
		System.out.println(stack);
		
	}

}
