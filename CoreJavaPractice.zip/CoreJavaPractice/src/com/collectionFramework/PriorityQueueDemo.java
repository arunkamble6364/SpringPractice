package com.collectionFramework;

import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;

public class PriorityQueueDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// priority queue doesn't allow null value
		
		Queue<String> queue = new PriorityQueue<>();
		queue.add("Amit");
		queue.add("Prashant");
		queue.add("Vaibhav");
		queue.add("Shravan");
		
		
		//System.out.println(queue);
		
		System.out.println("Head : " +queue.element() );
		System.out.println("Head : " +queue.peek() );
		
		Iterator<String> itr= queue.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
			
		}
		
		queue.remove();
		queue.poll();
		
		System.out.println("After removing the elements");
		Iterator<String> iterator = queue.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
			
		}
		
		
		

	}

}
