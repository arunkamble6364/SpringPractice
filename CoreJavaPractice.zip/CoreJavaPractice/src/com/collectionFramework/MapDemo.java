package com.collectionFramework;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

public class MapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Map<Integer, String> map4 = new HashMap<>();
		map4.put(1, "Suraj");
		map4.put(32, "Ajay");
		map4.put(19, "Viraj");
		map4.put(23, "Daya");
		
		for(Entry m : map4.entrySet()) {
			System.out.println(m.getKey()+ " " +m.getValue());
		}
		
		
		
		
		Map<Integer, String> map = new HashMap<>();
		map.put(1, "Vaibahv");
		map.put(10, "Chetan");
		map.put(8, "Aishwarya");
		map.put(2, "Navin");
		map.put(null, null);
		map.remove(2);

		System.out.println(map);

		Map<String, String> map2 = new LinkedHashMap<>();
		map2.put("1", "Sumit");
		map2.put("7", "Anil");
		map2.put("3", "Dipak");
		map2.put("10", "Amar");
		map2.put(null, null);

		System.out.println(map2);

		// Null value is not allowed in treeMap
		Map<Integer, Integer> map3 = new TreeMap<>();
		map3.put(1, 101);
		map3.put(4, 401);
		map3.put(10, 1001);
		map3.put(5, 501);
		map3.put(99, null);
		//System.out.println(map3);

		  for(Entry m : map3.entrySet()){    
			    System.out.println(m.getKey()+" "+m.getValue());    
			   }  
	}

}
