package com.collectionFramework;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class ArrayListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Iterator interface used to traverse list in forward direction only

		List<String> list = new ArrayList<>();
		list.add("Amit");
		list.add("Sumit");
		list.add("Pranav");
		list.add("Amit");

		// System.out.println(list);

		/*
		 * for (String name : list) { System.out.println(name);
		 * 
		 * }
		 */

		System.out.println("size of list is : " + list.size());

		System.out.println("name at first index :" + list.get(1));

		System.out.println("isEmptyMethod :" + list.isEmpty());

		System.out.println("Hashcode method : " + list.hashCode());

		// ListIterator interface used to traverse element in forward & backward direction
		
		ListIterator<String> itr = list.listIterator();
		while (itr.hasNext()) {
			System.out.println("Index is : " + itr.nextIndex() + " " + "value :"+  itr.next());

		}

		System.out.println("itr in backward direction ");
		
		while (itr.hasPrevious()) {
			System.out.println("Index is : " + itr.previousIndex() + "value"+  itr.previous());

		}

	}

}
