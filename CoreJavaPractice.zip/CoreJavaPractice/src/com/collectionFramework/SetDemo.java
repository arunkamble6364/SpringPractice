package com.collectionFramework;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Hashset allows us to store only one null value

		Set<String> set = new HashSet<>();
		set.add("Babu");
		set.add("Mahesh");
		set.add("Kishor");
		set.add("Atul");
		set.add(null);
		set.add(null);

		System.out.println(set);
		System.out.println(set.size());

		Set<Integer> set2 = new LinkedHashSet<>();
		set2.add(40);
		set2.add(20);
		set2.add(30);
		set2.add(40);
		set2.add(null);

		System.out.println(set2);

		// Null value is not allowed in treeset
		Set<String> set3 = new TreeSet<>();
		set3.add("Prafull");
		set3.add("Babu");
		set3.add("Akash");
		set3.add("Jemini");
		set3.add(null);
		System.out.println(set3);

	}

}
