package com.ComparatorDemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Student> students = new ArrayList<>();
		Student s1 = new Student(1, "Samit", 98);
		Student s2 = new Student(34, "Rohit", 34);
		Student s3 = new Student(21, "Amar", 56);
		Student s4 = new Student(6, "Babu", 22);

		students.add(s1);
		students.add(s2);
		students.add(s3);
		students.add(s4);

		System.out.println("Sorting based on rollNo");
		Collections.sort(students, new RollNoComparator());
		System.out.println(students);
		
		System.out.println("Sorting based on name" );
		Collections.sort(students, new NameComparator());
		System.out.println(students);
		
		System.out.println("Sorting based on age");
		Collections.sort(students, new AgeComparator());
		System.out.println(students);

	}

}
