package com.exception;

 class SelectionException extends Exception{
	 
	 public SelectionException(String s) {
		 super(s);
	 }
 }
 
 class Student{
	 
	 
	 public void demo() throws SelectionException {
		 display(98);
	 }
	 
	 public void display(int marks) throws SelectionException {
		 
		if(marks <80) {
			throw new ArithmeticException("you are not eligible");
		}
		else {
			System.out.println("you are eligible");
		}
	 }
	 
 }


public class ThrowsDemo {

	public static void main(String[] args) throws SelectionException {
		// TODO Auto-generated method stub

		Student s1 = new Student();
		s1.demo();
		System.out.println("welcome");
		
		
	}

}
