package com.exception;

public class ArithmaticExceptionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			int a = 50 / 0;

		} catch (ArithmeticException e) {
			System.out.println(e);

		}
		for(int i=0;i<=5;i++) {
			System.out.println(i);
		}
		System.out.println("rest of the code");

	}

}
