package com.exception;

class HeightException extends Exception{
	
	public HeightException(String s) {
		super(s);
	}
}

public class ThrowDemo {

	public static void main(String[] args) throws HeightException {
		// TODO Auto-generated method stub

		int height = 187;
		if(height<170) {
			throw new HeightException("not eligible");
		}else {
			System.out.println("eligible");
		}
		System.out.println("welcome");
	
		
		
	}

}
