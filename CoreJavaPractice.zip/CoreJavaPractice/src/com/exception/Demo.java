package com.exception;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			
			int a[] = new int[5];
			a[10] = 30/0;
			
		}catch (ArithmeticException e) {
			// TODO: handle exception
			System.out.println(e);
			
		}
		System.out.println("welcome");

	}

}
