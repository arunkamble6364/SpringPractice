package com.exception;

public class ArrayIndexOfDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			System.out.println("Heloo");
			int a[] = new int[5];
			System.out.println(a[10]);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println(e);
		}
		finally {
			System.out.println("welcome");
		}
		
		System.out.println("rest of the code");

	}

}
