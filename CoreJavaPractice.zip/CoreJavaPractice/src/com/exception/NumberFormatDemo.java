package com.exception;

public class NumberFormatDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			String s = "Bat";
			int i = Integer.parseInt(s);
			
		}catch(NumberFormatException e) {
			System.out.println(e);
		}
		System.out.println("rest of the code");
	}

}
