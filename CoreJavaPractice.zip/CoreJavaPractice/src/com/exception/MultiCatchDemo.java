package com.exception;

public class MultiCatchDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {

			int a[] = new int[5];
			int b = 60 / 0;
			System.out.println(a[10]);
		} catch (ArithmeticException e) {

			System.out.println("Arithmatic exception occures");
		} catch (ArrayIndexOutOfBoundsException e) {

			System.out.println(e);
		} catch (Exception e) {

			System.out.println(e);
		}

		System.out.println("welcome");
	}

}
