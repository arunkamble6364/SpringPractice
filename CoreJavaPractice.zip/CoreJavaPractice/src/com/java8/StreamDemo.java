package com.java8;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

class Product {

	int id;
	String name;
	int price;

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Product(int id, String name, int price) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
	}

}

public class StreamDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Product> products = new ArrayList<>();
		Product p1 = new Product(1, "Oppo", 40000);
		Product p2 = new Product(2, "Vivo", 65000);
		Product p3 = new Product(3, "Redmi", 54000);
		Product p4 = new Product(4, "Poco", 23000);

		products.add(p1);
		products.add(p2);
		products.add(p3);
		products.add(p4);

		/*
		 * List<Integer> products2 = products.stream().filter(p -> p.price >
		 * 30000).map(p -> p.price) .collect(Collectors.toList());
		 * 
		 * System.out.println(products2);
		 */

		products.stream().filter(p -> p.price == 40000).forEach(p -> System.out.println(p.name));

	}

}
