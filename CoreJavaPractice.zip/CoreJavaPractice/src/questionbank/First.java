package questionbank;

interface Demo{
	default void msg() {
		System.out.println("Hello");
	}
	
}
interface Demo2{
	default void msg() {
		System.out.println("Hello");
	}
	
}
class Sample implements Demo,Demo2{
	
}

public class First {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sample s  = new Sample();

	}

}
