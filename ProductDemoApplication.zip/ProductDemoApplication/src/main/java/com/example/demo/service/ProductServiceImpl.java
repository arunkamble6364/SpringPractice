package com.example.demo.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.ProductDao;
import com.example.demo.model.Product;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDao productDao;
	
	
	@Override
	public List<Product> getAllProducts() {
		return productDao.getAllProducts();
		
	}


	/*
	 * @Override public Product getProductById(String productId) { return
	 * productDao.getProductById(productId); }
	 */

	
	@Override
	public Product getProductById(String id) {
		return productDao.getProductById(id);
	}
	

	@Override
	public List<Product> getAllProductsByCategory(String category) {
		
		return productDao.getAllProducts().stream().filter(p->p.getCategory().equals(category)).collect(Collectors.toList());
	}


	@Override
	public void insertProduct(Product p) {
	
		productDao.insertProduct(p);
		
		
	}


	@Override
	public void updateProduct(Product p) {
		productDao.updateProduct(p);
		
	}


	@Override
	public void DeleteProduct(int id) {
		productDao.DeleteProduct(id);
		
	}


	


	


	/*
	 * @Override public List<Product> getProductByCategory(String category) { return
	 * productDao.getProductByCategory(category); }
	 */
	
	
	
}
