package com.example.demo.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;

import com.example.demo.mapper.ProductMapper;
import com.example.demo.model.Product;

@Repository
public class ProductDaoImpl implements ProductDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public List<Product> getAllProducts() {

		String sql = "select * from product";
		return jdbcTemplate.query(sql, new ProductMapper());

	}

	/*
	 * @Override public Product getProductById(String productId) { String sql
	 * ="select productId, name, unit_Price, category,description,manufacturer from product where productId='"
	 * +productId+"'"; //String sql = "select * from product where productId=?";
	 * 
	 * return jdbcTemplate.queryForObject(sql,new ProductMapper());
	 * 
	 * }
	 */

	@SuppressWarnings("deprecation")
	@Override
	public Product getProductById(String id) {
		String sql = "select * from product where productid=?";
		return jdbcTemplate.queryForObject(sql, new Object[] { id }, new ProductMapper());
	}

	@Override
	public List<Product> getProductByCategory(String category) {
		String sql = "select productId, name, unit_Price, category,description,manufacturer from product where category='"
				+ category + "'";
		return jdbcTemplate.query(sql, new ProductMapper());
	}

	@Override
	public void insertProduct(Product p) {
		String sql = "insert into product(productId,name,unit_Price,category,description,manufacturer)values(?,?,?,?,?,?)";
		jdbcTemplate.update(sql, new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, p.getProductId());
				ps.setString(2, p.getName());
				ps.setInt(3, p.getUnitPrice());
				ps.setString(4, p.getCategory());
				ps.setString(5, p.getDescription());
				ps.setString(6, p.getManufacturer());

			}

		});

	}

	@Override
	public void updateProduct(Product p) {
		String sql = "update product set name=?,unit_Price=?,category=?,description=?,manufacturer=? where productId=?";
		jdbcTemplate.update(sql, new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {

				ps.setString(1, p.getName());
				ps.setInt(2, p.getUnitPrice());
				ps.setString(3, p.getCategory());
				ps.setString(4, p.getDescription());
				ps.setString(5, p.getManufacturer());
				ps.setString(6, p.getProductId());

			}

		});
	}

	@Override
	public void DeleteProduct(int id) {
		 String query="delete from product where productId="+id;
         jdbcTemplate.update(query);
		
	}

	

}
