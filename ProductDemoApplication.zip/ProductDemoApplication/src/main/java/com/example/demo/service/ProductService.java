package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Product;

public interface ProductService {

	List<Product> getAllProducts();
	//public Product getProductById(String productId);
    //public List< Product> getProductByCategory(String category);
    
    List<Product> getAllProductsByCategory(String category);
    public Product getProductById(String id);
    public void insertProduct(Product p);
    public void updateProduct(Product p);
   // public int deleteById(int id);
    
    public void DeleteProduct(int id);
}
 