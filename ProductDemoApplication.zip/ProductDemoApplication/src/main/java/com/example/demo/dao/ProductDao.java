package com.example.demo.dao;

import java.util.List;

import com.example.demo.model.Product;

public interface ProductDao {

	List<Product> getAllProducts();
	//public Product getProductById(String productId);
    public List< Product> getProductByCategory(String category);
    
    Product getProductById(String id);
    public void insertProduct(Product p);
    public void updateProduct(Product p);
    //public int deleteById(int id);
    
    public void DeleteProduct(int id);
    
	
}
