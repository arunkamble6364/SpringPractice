package com.example.demo.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.example.demo.model.Product;

public class ProductMapper implements RowMapper<Product> {

	@Override
	public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		 Product p1=new Product();
	        p1.setProductId(rs.getString("productId"));
	        p1.setName(rs.getString("name"));
	        p1.setDescription(rs.getString("description"));
	        p1.setCategory(rs.getString("category"));
	        p1.setManufacturer(rs.getString("manufacturer"));
	        p1.setUnitPrice(rs.getInt("unit_Price"));
	        return p1;
		
		
	}

}
