package com.example.demo.controller;

import java.io.File;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.logger.ProcessingTimeInterceptor;
import com.example.demo.model.Product;
import com.example.demo.service.ProductService;
import com.example.demo.validator.ProductValidator;

@Controller
@RequestMapping("/products")
public class ProductController {

	@Autowired
	ProductService productService;

	@Autowired
	ProductValidator validator;

	@InitBinder
	public void initBinder(WebDataBinder binder) {

		binder.setValidator(validator);
	}

	// private static final Logger LOGGER =
	// Logger.getLogger(ProductController.class);

	@RequestMapping(method = RequestMethod.GET, value = "/all")
	public String getAllProducts(ModelMap model) {

		List<Product> products = productService.getAllProducts();
		model.addAttribute("products", products);
		return "allProducts";
	}

	/*
	 * @RequestMapping(method = RequestMethod.GET , value = "/get/{productId}")
	 * public String getProuctById(@PathVariable("productId") String productId
	 * ,ModelMap model) {
	 * 
	 * // Product p=productService.getProductById(productId);
	 * model.addAttribute("product",productService.getProductById(productId));
	 * return "oneProduct"; }
	 */

	@RequestMapping(method = RequestMethod.GET, value = "/get")
	public String getProductById(@RequestParam("id") String productId, ModelMap model) {
		Product p1 = productService.getProductById(productId);
		model.addAttribute("product", p1);
		return "oneProduct";

	}

	@RequestMapping(method = RequestMethod.GET, value = "/add")
	public String getProductAddForm(ModelMap model) {

		/*
		 * Product p1 = new Product(); p1.setProductId("11524e"); p1.setName("cinthol");
		 * model.addAttribute("newProduct" ,p1); return "addProduct";
		 */

		model.addAttribute("newProduct", new Product());
		return "addProduct";

	}

	@RequestMapping(method = RequestMethod.POST, value = "/add")
	public String addProduct(@ModelAttribute("newProduct") @Valid Product product, BindingResult result,
			HttpServletRequest request) {

		if (result.hasErrors())
			return "addProduct";

		MultipartFile productImage = product.getFile();
		String rootDirectory = request.getSession().getServletContext().getRealPath("/");
		try {

			productImage.transferTo(new File(rootDirectory + "resources\\images\\" + product.getProductId() + ".jpg"));
		} catch (Exception ex) {

		}
		productService.insertProduct(product);

		return "redirect:/products/all";

	}

	@ExceptionHandler(SQLIntegrityConstraintViolationException.class)
	public ModelAndView handlePrimaryKeyViolation(Exception ex) {

		ModelAndView mv = new ModelAndView();
		mv.addObject("exception", ex.getMessage());
		mv.setViewName("error.jsp");
		return mv;

	}

	/*
	 * @RequestMapping(method = RequestMethod.GET , value = "/all/{category}")
	 * public String getProductByCategory(@PathVariable("category") String
	 * category,ModelMap model){
	 * 
	 * // List<Product> products = productService.getAllProducts();
	 * model.addAttribute("products",
	 * productService.getProductByCategory(category)); return "allProducts"; }
	 */

	@RequestMapping(method = RequestMethod.GET, value = "/all/{category}")
	public String getAllProductsByCategory(ModelMap model, @PathVariable("category") String category) {

		List<Product> products = productService.getAllProductsByCategory(category);
		model.addAttribute("products", products);
		return "allProducts";
	}

	@RequestMapping(method = RequestMethod.GET, value = "/update")
	public String updateProductform(@RequestParam String id, ModelMap model) {
		Product p = new Product();
		p = productService.getProductById(id);
		System.out.println("update is called");
		// productService.updateProduct(product);
		model.addAttribute("productId", p.getProductId());
		model.addAttribute("name", p.getName());
		model.addAttribute("unit_Price", p.getUnitPrice());
		model.addAttribute("category", p.getCategory());
		model.addAttribute("description", p.getDescription());
		model.addAttribute("manufacturer", p.getManufacturer());
		model.addAttribute("newProduct", p);
		return "addProduct";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/update")
	public String updateProduct(@ModelAttribute("newProduct") Product product) {
		System.out.println("Controller");
		productService.updateProduct(product);
		// model.addAttribute("newProduct" ,new Product());
		return "redirect:/products/all";
	}

	@RequestMapping(method = { RequestMethod.GET, RequestMethod.DELETE }, value = "/delete")
	public String DeleteProduct(@RequestParam int id) {
		productService.DeleteProduct(id);

		return "redirect:/products/all";
	}

}
