package com.main;

public class Employee {

	private int empId;
	private String ename;
	private Address address;

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(int empId, String ename) {
		super();
		this.empId = empId;
		this.ename = ename;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}
	
	

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public void showDetails() {

		System.out.println("Employee Id is : " + empId);
		System.out.println("Employee name is: " + ename);

	}

	public void empDetails() {

		System.out.println("Emp Id is: " + empId);
		System.out.println("Emp name is :" + ename);
		System.out.println(address);

	}

}
