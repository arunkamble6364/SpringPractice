package com.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");

		// using setter injection
		Employee obj1 = (Employee) context.getBean("emp");
		obj1.showDetails();

		// using constructor injection
		Employee obj2 = (Employee) context.getBean("empcons");
		obj2.showDetails();

		Employee obj3 = (Employee) context.getBean("empbean");
		obj3.empDetails();

	}

}
